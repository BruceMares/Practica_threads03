public class Tortuga extends Corredor {

    private static final int AVANCE_RAPIDO = 3;
    private static final int RESBALON = - 6;
    private static final int AVANCE_LENTO = 1;

    @Override
    protected String getNombre() {
        return "T";
    }

    @Override
    protected int posicionesParaAvanzar() {
        int numeroRandomDelCeroAlCien = numeroRandomDelCeroAlCien();
        if (numeroRandomDelCeroAlCien < 50) {
            return AVANCE_RAPIDO;
        } else if (numeroRandomDelCeroAlCien < 70) {
            return RESBALON;
        } else {
            return AVANCE_LENTO;
        }
    }

}
