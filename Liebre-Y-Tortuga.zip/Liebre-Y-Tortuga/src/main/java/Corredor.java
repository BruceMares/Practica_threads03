import java.util.Random;

abstract class Corredor implements Runnable {

    private int posicion;
    private int segundos;
    private int meta;
    private int salida;

    protected Corredor() {
        this.meta = 100;
        this.posicion = 0;
        this.salida = 0;
        this.segundos = 0;
    }

    protected abstract String getNombre();

    protected abstract int posicionesParaAvanzar();

    @Override
    public void run() {
        while (!llegoALaMeta()) {
            imprimirPosicion();
            esperarUnSegundo();
            segundos += 1;
            int posicionesParaAvanzar = posicionesParaAvanzar();
            if (posicion + posicionesParaAvanzar < salida)
                posicion = salida;
            else if (posicion + posicionesParaAvanzar > meta)
                posicion = meta;
            else
                posicion += posicionesParaAvanzar;
        }
        mostrarResultados();
    }

    private void mostrarResultados() {
        System.out.println(getNombre() + " tardo " + segundos + " segundos para llegar a la meta");
    }

    private void imprimirPosicion() {
        String lineaDeCorredor = "";
        for (int i = 0; i < posicion; i++) {
            lineaDeCorredor += " ";
        }
        lineaDeCorredor += getNombre();
        System.out.println(lineaDeCorredor);
    }

    private void esperarUnSegundo() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    protected int numeroRandomDelCeroAlCien() {
        Random random = new Random();
        return random.nextInt(101);
    }

    private boolean llegoALaMeta() {
        return posicion == meta;
    }

}
