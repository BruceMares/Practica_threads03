public class Liebre extends Corredor {

    private static final int DUERME = 0;
    private static final int GRAN_SALTO = 9;
    private static final int RESBALON_GRANDE =  - 12;
    private static final int PEQUENO_SALTO = 1;
    private static final int RESBALON_PEQUENO =  - 2;


    @Override
    protected String getNombre() {
        return "L";
    }

    @Override
    protected int posicionesParaAvanzar() {
        int numeroRandomDelCeroAlCien = numeroRandomDelCeroAlCien();
        if (numeroRandomDelCeroAlCien < 20) {
            return DUERME;
        } else if (numeroRandomDelCeroAlCien < 40) {
            return GRAN_SALTO;
        } else if (numeroRandomDelCeroAlCien < 50) {
            return RESBALON_GRANDE;
        } else if (numeroRandomDelCeroAlCien < 80) {
            return PEQUENO_SALTO;
        } else {
            return RESBALON_PEQUENO;
        }
    }


}
