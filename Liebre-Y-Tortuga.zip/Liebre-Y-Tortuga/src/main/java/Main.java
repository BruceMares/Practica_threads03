public class Main {

    public static void main(String[] args) {
        new Thread(new Liebre()).start();
        new Thread(new Tortuga()).start();
    }

}
